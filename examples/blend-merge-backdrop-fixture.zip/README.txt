Flipbook Studio editable project v1.
Import through the project archive button.
History is intentionally not included; current editable layers, clips, palettes and tilemaps are retained.
